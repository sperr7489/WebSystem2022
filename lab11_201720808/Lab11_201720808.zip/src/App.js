import InputClock from "./InputClock";
import Main from "./Main";

function App() {
  return (
    <div className="App">
      <Main></Main>
    </div>
  );
}

export default App;
