const data = [
  {
    koreanName: "김지은",
    englishName: "Kim Ji Eun",
    photoURL:
      "http://www.newsfreezone.co.kr/news/photo/202204/376538_357971_611.jpg",
    studentId: "202212345",
    department: "소프트웨어학과",
  },
  {
    koreanName: "배수지",
    englishName: "Bae Suzy",
    photoURL: "https://t1.daumcdn.net/cfile/tistory/991516355E53EB3125",
    studentId: "202112345",
    department: "사이버보안학과",
  },
  {
    koreanName: "이주빈",
    englishName: "Lee Ju Bin",
    photoURL:
      "http://www.bodonews.com/imgdata/bodonews_com/202107/2021072847086900.jpg",
    studentId: "201812345",
    department: "미디어학과",
  },
];
export default data;
